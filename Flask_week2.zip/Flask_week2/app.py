from flask import Flask, Blueprint, render_template, url_for, redirect, request
from views import views


app = Flask(__name__)

app.register_blueprint(views)

@app.errorhandler(404)
def page_not_found(e):
    return render_template("page_not_found.html"),404

@app.errorhandler(500)
def page_not_found(e):
    return render_template("internal_server_error.html"),500

@app.route("/services", methods=["POST", "GET"])
def services():
    global answer_list
#

if __name__ == "__main__":
    app.run(debug = True, port = 8000)