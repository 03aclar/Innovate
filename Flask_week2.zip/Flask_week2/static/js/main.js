function funcExample () {
    console.log("hello world");
};

let my_name = "Ash" 
    
const my_last_name = "Clarke"

if (my_name === "Ash") {
console.log(`hello, ${my_name}!`)
} else {
    console.log("you're not Ash")
}

function reallygoodfunction (num1, num2) {
    let result = num1 + num2
    return result
}

function taskHider () {
    let element = document.getElementById("task-box")
    element.classList.toggle("hidden")
}

function stateCheck() {
    // console.log(`Page loading ${state}!!`)
    let element = document.body;
    let state = localStorage.getItem("state")
    let btn = document.getElementById("btn")
    if (state !== 'dark') {
        element.className = "light-mode";
        btn.innerHTML = "🌑"
        console.log(state)
    } else if (state === "dark") {
        element.className = "dark-mode";
        btn.innerHTML = "☀️"
        console.log(state)
    }
}
function darkMode() {
    let state = localStorage.getItem("state")
    let element = document.body;
    let btn = document.getElementById("btn")
    if (state !== 'dark') {
        element.className = "dark-mode";
        localStorage.setItem("state", "dark");
        btn.innerHTML = "☀️"
        console.log(state)
    } else if (state === 'dark') {
        element.className = "light-mode";
        btn.innerHTML = "🌑"
        localStorage.setItem("state", "light");
        console.log(state)
    }
}